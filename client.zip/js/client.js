const addMessage = (userName, message) => {
    $("#chat_content ul").append(`
        <li>
            <span class="userName">${ userName } : </span>
            ${ message }
        </li>`);
};
