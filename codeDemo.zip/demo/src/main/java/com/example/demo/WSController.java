package com.example.demo;

import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.handler.annotation.SendTo;
import org.springframework.stereotype.Controller;

@Controller
public class WSController {

    @MessageMapping("/message")
    @SendTo("/topic/message")
    public MessageDto broadcast(MessageDto messageDto) {
        return messageDto;
    }
}
