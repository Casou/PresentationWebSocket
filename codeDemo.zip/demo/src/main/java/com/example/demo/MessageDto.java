package com.example.demo;

import lombok.Data;

@Data
public class MessageDto {

    private String userName;
    private String message;

}
