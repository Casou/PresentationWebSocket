const addMessage = (userName, message) => {
    $("#chat_content ul").append(`
        <li>
            <span class="userName">${ userName } : </span>
            ${ message }
        </li>`);
};


const sockjs = new SockJS("/chat");
const stompClient = Stomp.over(sockjs);

const callback = () => {
    stompClient.subscribe("/topic/message", (response) => {
       const messageDto = JSON.parse(response.body);
       addMessage(messageDto.userName, messageDto.message);
    });
};

stompClient.connect({}, callback);

$("#submit_button").click(() => {
    stompClient.send("/message", {}, JSON.stringify({
        userName : $("#input_userName").val(),
        message : $('#input_message').val()
    }))
});